# MetaSAG Usage 
## Step 8. HUMAnN Path.
```
import BarcodeDeal as bcd



```