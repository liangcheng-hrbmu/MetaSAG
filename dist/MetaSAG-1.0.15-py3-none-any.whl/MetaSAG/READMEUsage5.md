# MetaSAG Usage 
## Step 5. Build phylogenetic tree.
```
import BarcodeDeal as bcd



```