# MetaSAG Usage 
## Step 6. Species to Strain resolved genomes.
```
import BarcodeDeal as bcd



```