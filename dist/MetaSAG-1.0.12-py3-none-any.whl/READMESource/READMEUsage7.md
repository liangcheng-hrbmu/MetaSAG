# MetaSAG Usage 
## Step 7. Horizontal Gene Transfer.
```
import BarcodeDeal as bcd



```