# MetaSAG Usage 
## Step 4. Quality control and integration annotation of assembled genome.
```
import BarcodeDeal as bcd



```