# Step 3. MetaPhlAn4 annotates the reads and classifies droplets
```
import BarcodeDeal as bcd



```